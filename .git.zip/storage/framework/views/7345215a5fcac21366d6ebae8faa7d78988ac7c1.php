<html>
    <table>
        <thead>
            <tr>
                <th>Empresa</th>
                <th>Sucursal</th>
                <th>Registro patronal</th>
                <th>Nómina</th>
                <th>Apellido paterno</th>
                <th>Apellido materno</th>
                <th>Nombre(s)</th>
                <th>R.F.C</th>
                <th>CURP</th>
                <th>Num. IMSS</th>
                <th>Fecha ingreso</th>
                <th>Puesto</th>
                <th>Departamento</th>
                <th>Cuenta bancaria</th>
                <th>Sueldo diario</th>
                <th>Sueldo integrado</th>
                <th>Sueldo complemento</th>
                <th>Domicilio</th>
                <th>Colonia</th>
                <th>Municipio</th>
                <th>Estado</th>
                <th>Codigo postal</th>
                <th>Telefono</th>
            </tr>
        </thead>
        <tbody>
            
        </tbody>
    </table>
</html><?php /**PATH C:\xampp\htdocs\api_serteza\resources\views/formato_movimiento.blade.php ENDPATH**/ ?>