<html>
    <table>
        <thead>
        <tr>
            <th>Clave</th>
            <th>Nombre</th>
            <?php $__currentLoopData = $conceptos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $concepto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th style="text-align: center; background-color: lightseagreen;"><?php echo e($concepto->id_concepto); ?></th>
                <th colspan="2" style="text-align: center; background-color: salmon"><?php echo e($concepto->concepto); ?></th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
        <tr>
            <th></th>
            <th></th>
            <?php $__currentLoopData = $conceptos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $concepto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th style="text-align: center;">Unidades</th>
                <th style="text-align: center;">Importe</th>
                <th style="text-align: center;">Saldo</th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($empleado->id_empleado); ?></td>
                <td><?php echo e($empleado->nombre); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</html>
<?php /**PATH C:\xampp\htdocs\api_serteza\resources\views/prueba.blade.php ENDPATH**/ ?>