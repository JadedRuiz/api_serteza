<html>
    <table>
        <thead>
            <tr>
                <th colspan="3">
                    <img src="<?php echo e($datos_empresa->url_foto); ?>" width="90">
                </th>
                <th colspan="12" style="font-size: 24px;">
                    CONTROL DE ALTAS DE EMPLEADOS
                </th>
            </tr>
            <tr>
                <th>Empresa</th>
                <th>Cliente</th>
                <th>Sucursal</th>
                <th>Registro patronal</th>
                <th>Nómina</th>
                <th>Apellido paterno</th>
                <th>Apellido materno</th>
                <th>Nombre(s)</th>
                <th>R.F.C</th>
                <th>CURP</th>
                <th>Num. IMSS</th>
                <th>Fecha ingreso</th>
                <th>Puesto</th>
                <th>Departamento</th>
                <th>Cuenta bancaria</th>
                <th>Sueldo diario</th>
                <th>Sueldo integrado</th>
                <th>Sueldo complemento</th>
                <th>Calle</th>
                <th>Numero interior</th>
                <th>Numero exterior</th>
                <th>Cruzamiento uno</th>
                <th>Cruzamiento dos</th>
                <th>Colonia</th>
                <th>Municipio</th>
                <th>Estado</th>
                <th>Codigo postal</th>
                <th>Telefono</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($datos_empresa->empresa); ?></td>
                    <td><?php echo e($empleado->cliente); ?></td>
                    <td><?php echo e($empleado->sucursal); ?></td>
                    <td></td>
                    <td><?php echo e($empleado->nomina); ?></td>
                    <td><?php echo e($empleado->apellido_paterno); ?></td>
                    <td><?php echo e($empleado->apellido_materno); ?></td>
                    <td><?php echo e($empleado->nombre); ?></td>
                    <td><?php echo e($empleado->rfc); ?></td>
                    <td><?php echo e($empleado->curp); ?></td>
                    <td><?php echo e($empleado->numero_seguro); ?></td>
                    <td><?php echo e(date("d-m-Y",strtotime($empleado->fecha_ingreso))); ?></td>
                    <td><?php echo e($empleado->puesto); ?></td>
                    <td><?php echo e($empleado->departamento); ?></td>
                    <td><?php echo e($empleado->cuenta); ?></td>
                    <td><?php echo e($empleado->sueldo_diario); ?></td>
                    <td><?php echo e($empleado->sueldo_integrado); ?></td>
                    <td><?php echo e($empleado->sueldo_complemento); ?></td>
                    <td><?php echo e($empleado->calle); ?></td>
                    <td><?php echo e($empleado->numero_interior); ?></td>
                    <td><?php echo e($empleado->numero_exterior); ?></td>
                    <td><?php echo e($empleado->cruzamiento_uno); ?></td>
                    <td><?php echo e($empleado->cruzamiento_dos); ?></td>
                    <td><?php echo e($empleado->colonia); ?></td>
                    <td><?php echo e($empleado->municipio); ?></td>
                    <td><?php echo e($empleado->estado); ?></td>
                    <td><?php echo e($empleado->codigo_postal); ?></td>
                    <td><?php echo e($empleado->telefono); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</html><?php /**PATH C:\xampp\htdocs\api_serteza\resources\views/formato_alta_mod.blade.php ENDPATH**/ ?>